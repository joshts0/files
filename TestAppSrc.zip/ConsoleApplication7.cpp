﻿// ConsoleApplication7.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <filesystem>
#include <fstream>
#include <system_error>
#include <Windows.h>
#include <fileapi.h>

int main(int argc, char* argv[])
{
    if (argc != 3)
    {
        ::MessageBoxA(NULL, "USAGE: TestApp.exe absolute_filename_of_logFile absolute_path_to_dir_to_list_files", "ERROR", MB_OK);
        return -1;
    }

    auto logFileName = std::filesystem::path{ argv[1] };
    auto dirListPath = std::filesystem::path{ argv[2] };

    auto outfile{ std::ofstream{logFileName, std::ofstream::out  } };
    bool logFileHasPermission = false;
    bool dirHasPermission = false;
    try 
    {
        if (!outfile.is_open())
        {
            char buffer[1024]{};
            const size_t len = strerror_s<1024>(buffer, errno);
            std::stringstream error{"Cannot open log file"};
            error << "\nA System error occured\nerrno: " << errno << "\nError Message: " << std::string_view{ buffer, std::strlen(buffer) } << "\n";
            ::MessageBoxA(NULL, error.str().c_str(), "ERROR", MB_OK);
            return 0;
        }
        outfile.exceptions(std::ofstream::failbit | std::ofstream::badbit);
        outfile << "Start writing Log\n:";
        logFileHasPermission = true;
        for (auto& iter : std::filesystem::directory_iterator(dirListPath))
        {
            dirHasPermission = true;
            if (iter.is_regular_file())
            {
                outfile << iter.path() << "\n";
            }
        }
        outfile << std::endl;
        outfile.flush();

        if (logFileHasPermission && dirHasPermission)
        {
            std::string end = "App container program, TestApp, successfully wrote the directory listing "+dirListPath.string()+" to log file, "+logFileName.string()+" and all permission are correctly set";
            ::MessageBoxA(NULL, end.c_str(), "SUCCESS", MB_OK);
        }
        else 
        {
            throw std::runtime_error("This should have not happened. Please ensure the directory exists and is not empty.");
        }
        
    }
    catch (std::system_error& se)
    {
        char buffer[1024]{};
        const size_t len = strerror_s<1024>(buffer, errno);
        std::stringstream error{};
        
        if (errno != 0)
        {
            error << "A System error occured\nerrno: " << errno << "\nError Message: " << std::string_view{ buffer, std::strlen(buffer) }.data() << "\n";
        }
        
        if (!logFileHasPermission)
        {
            error << "\nApp container program, TestApp, cannot open log file " + logFileName.string() + "\nPermission may not be properly set.";
        }
        else if (!dirHasPermission)
        {
            error <<  "App container program, TestApp, only has access to log file, " + logFileName.string() + ", and cannot not list the content of directory, " + dirListPath.string()
                       + "\n\nTherefore Permission has not be properly set on the directory, " + dirListPath.string();
        }
        ::MessageBoxA(NULL, error.str().c_str(), "ERROR", MB_OK);
    }
    catch (std::exception& e)
    {
        std::stringstream error{ "App container program, TestApp, cannot deduce the problem." };
        error << "\n\nFailed with: " << e.what() << std::endl;
        ::MessageBoxA(NULL, error.str().c_str(), "ERROR", MB_OK);
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
